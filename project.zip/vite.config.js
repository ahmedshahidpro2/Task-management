import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react-swc';

export default defineConfig({
  plugins: [react({
    jsxRuntime: 'automatic'
  })],
  
  resolve: {
    alias: {
      // Setting up the base URL for src
      'app-redux/': '/src/app-redux/',
      'assets/': '/src/assets/',
      'common/': '/src/common/',
      'config/': '/src/config/',
      'modules/': '/src/modules/',
      'routes/': '/src/routes/',
    }
  },

  // esbuild: {
  //   loader: 'jsx',
  //   // Add this if you want to check JS
  //   // This assumes you have TypeScript installed as a dependency.
  //   jsxFactory: 'React.createElement',
  //   jsxInject: 'import React from "react";',
  // },

  // optimizeDeps: {
  //   esbuildOptions: {
  //     loader: {
  //       '.js': 'jsx',
  //     },
  //   },
  // },

  // ... Rest of your config
});
