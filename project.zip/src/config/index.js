/* global UIENV */

const API_AUTH_URL = import.meta.env.VITE_APP_CSH_API_AUTH_URL || 'http://localhost:3000/';  //staging
const API_BASE_URL = import.meta.env.VITE_APP_CSH_API_BASE_URL || 'http://localhost:3000/';  //staging

let config = {
    // 'moduleURL': envURL || 'http://127.0.0.1:3000',
    'sample': API_BASE_URL + '/sample',
    'auth_sample': API_AUTH_URL + '/auth_sample',
};

let pagination_params = {
    page_size: import.meta.env.VITE_APP_PAGE_SIZE || 500,
    page_No: import.meta.env.VITE_APP_PAGE_NO || 1,
};

// config.env = env;
config.API_AUTH_URL = API_AUTH_URL;
config.API_BASE_URL = API_BASE_URL;

export default config;
