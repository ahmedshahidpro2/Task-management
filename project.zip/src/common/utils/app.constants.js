export const defaultOption = { name: "Please select", optionType: "default" };
