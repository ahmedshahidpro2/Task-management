/** Only Frontend Validation **/

export const getFormikErrorClass = (obj, name, base = "", str = "") => {
  let error = null;
  if (!obj) {
    return base;
  }

  if (obj && obj.type === "formik") {
    let message = obj && obj.error;
    if (name.includes("[")) {
      // Array field
      const { arrayName, index, fieldName } = parseFieldName(name);

      if (arrayName && index > -1 && fieldName) {
        const arrayTouched = message && message.touched && message.touched[arrayName];
        const fieldTouched = arrayTouched && arrayTouched[index] && arrayTouched[index][fieldName];

        if (fieldTouched) {
          const arrayErrors = message && message.errors && message.errors[arrayName];
          const fieldErrors = arrayErrors && arrayErrors[index] && arrayErrors[index][fieldName];

          error = Boolean(fieldErrors);
        }
      }
    } else {
      // Individual field
      error = Boolean(message && message.touched && message.touched[name] && message.errors && message.errors[name]);
    }
  } else {
    let message = obj && obj.error;
    if (message) {
      error = Boolean(message[name] && message[name][0]);
    }
  }
  return error ? `${base} ${str}` : base;
};

export const getFormikErrorMessage = (obj, name) => {
  if (!obj) {
    return null;
  }

  const { error } = obj;
  let errorText = "";

  if (obj.type === "formik") {
    if (name.includes("[")) {
      // Array field
      const { arrayName, index, fieldName } = parseFieldName(name);

      if (arrayName && index > -1 && fieldName) {
        const arrayTouched = error && error.touched && error.touched[arrayName];
        const arrayErrors = error && error.errors && error.errors[arrayName];
        const fieldTouched = arrayTouched && arrayTouched[index] && arrayTouched[index][fieldName];
        const fieldErrors = arrayErrors && arrayErrors[index] && arrayErrors[index][fieldName];

        if (fieldTouched && fieldErrors) {
          errorText = fieldErrors;
        }
      }
    } else {
      // Individual field
      const touched = error && error.touched && error.touched[name];
      const fieldErrors = error && error.errors && error.errors[name];

      if (touched && fieldErrors) {
        errorText = fieldErrors;
      }
    }
  }

  return errorText ? <div className="invalid-feedback d-block">{errorText}</div> : null;
};


function parseFieldName(str) {
  const regex = /^(.*?)\[(\d+)\]\.(.*)$/;
  const matches = str.match(regex);

  if (matches) {
    const arrayName = matches[1];
    const index = parseInt(matches[2]);
    const fieldName = matches[3];

    if (isNaN(index)) {
      return null;
    }

    return { arrayName, index, fieldName };
  } else if (str.includes('.')) {
    return null;
  } else {
    return { fieldName: str };
  }
}