import React from 'react';
import { Icon } from '@iconify/react';

const defaultIconProps = {
    className: "icon alert-icon",
    width: 24,
    height: 24,
    stroke: "currentColor",
}

const Alert = ({ title = "", text = "", type = "info", closeable = false }) => {
    return (
        <div className={`alert alert-${type} alert-dismissible`} role="alert">
            <div className="d-flex">
                <div>
                    {type === "danger" ?
                        <Icon icon="tabler:alert-circle"  {...defaultIconProps} />
                        :
                        type === "success" ?
                        <Icon icon="tabler:checks"  {...defaultIconProps} />
                            :
                            type === "warning" ?
                            <Icon icon="tabler:alert-triangle"  {...defaultIconProps} />
                                :
                                <Icon icon="tabler:info-circle"  {...defaultIconProps} />
                    }

                </div>
                <div>
                    <h4 className="alert-title">{title}</h4>
                    <div className="text-muted">{text}</div>
                </div>
            </div>
            {closeable &&
                <a className="btn-close" data-bs-dismiss="alert" aria-label="close" />}

        </div>

    )
}


export default Alert;