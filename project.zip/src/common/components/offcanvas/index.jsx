import React from "react";

const OffCanvas = ({
    show,
    width,
    orientation,
    children,
}) => {
    return (
        <>
            <div className={`offcanvas-backdrop fade ${show ? "show" : ""}`}></div>
            <div
                className={`offcanvas offcanvas-${orientation} ${show ? "show" : ""} w-${width}`}
                tabIndex={-1}
                id="offcanvasEnd"
                aria-labelledby="offcanvasEndLabel"
                aria-modal="true"
                role="dialog"
                style={{ zIndex: 1051 }} // set higher zIndex than backdrop to be on top of it
            >
                {children}
            </div>
        </>
    );
};

export const OffCanvasHeader = ({ title, handleClose }) => {
    return (
        <div className="offcanvas-header py-3 border border-1">
            <h2 className="offcanvas-title" id="offcanvasEndLabel">
                {title}
            </h2>
            <button
                type="button"
                className="btn-close text-reset"
                data-bs-dismiss="offcanvas"
                aria-label="Close"
                onClick={handleClose}
            />
        </div>
    );
};

export const OffCanvasBody = ({ children }) => {
    return (
        <div className="offcanvas-body p-3">
            {children}
        </div>
    );
};

export const OffCanvasFooter = ({ children }) => {
    return (
        <div className="offcanvas-footer py-3">
            {children}
        </div>
    );
};

OffCanvas.defaultProps = {
    width: "25",
    orientation: "end", /* start, top, end, bottom */
};

export default OffCanvas;
