import { useEffect } from "react";
import { Icon } from '@iconify/react';
import { setTheme, toggleTheme } from "../../../utils/app.util";
import { useThemeState } from "app-redux/hooks/useThemeState";
import { useAppSelector } from "../../../../app-redux/hooks";
import { selectUser } from "../../../../app-redux/auth/authSlice";

const Header = (props) => {
  const { themeState, setThemeState } = useThemeState();

  const currentUser = useAppSelector(selectUser);
  console.log("current user", currentUser.id);

  const tTheme = () => {
    const theme = toggleTheme(themeState);
    setThemeState(theme)
  };

  useEffect(() => {
    setTheme(themeState);
  }, []);

  return (
    <>
      <div className="page-header d-print-none">
        <div className="container-fluid">

          <div className="row g-2 align-items-center">
            <div className="col">
              <div className="row align-items-center">

                <div className="col-auto desktop-responsive">
                  <button type="button" className="btn btn-icon" onClick={props.toggleSidebar}>
                    <Icon icon="mdi:menu" />
                    {/* <IconMenu2 /> */}
                  </button>
                </div>

                <div className="col">
                  {/* Page pre-title */}
                  <div className="page-pretitle">Overview</div>
                  <h2 className="page-title">{props?.title}</h2>
                </div>
              </div>
            </div>

            {/* Page title actions */}
            <div className="col-auto ms-auto d-print-none">
              <div className="btn-list">

                <span className="btn btn-facebook w-25 btn-icon cursor-pointer"

                  title="Enable light mode"
                  onClick={() => tTheme()}
                >
                  {themeState === 'dark' ? <Icon icon="mdi:theme-light-dark" width="1.5em" height="1.5em" /> : <Icon icon="mdi:theme-light-dark" width="1.5em" height="1.5em" />}
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>

    </>
  );
};

export default Header;
