import { useState, useEffect } from "react";
import Header from "./header";
import Footer from "./footer";
import SidebarResponsive from "./sidebar-responsive";
import SidebarDesktopContent from "./sidebar-desktop";
import { selectStatus } from "app-redux/auth/authSlice";
import CLoader from "../../loader";
import { useAppSelector } from "app-redux/hooks";

const LayoutVerticalTransparent = (props) => {
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [loader, showLoader] = useState(false);
  const authStatus = useAppSelector(selectStatus);
  //const productStatus = useAppSelector(selectProductStatus)


  const toggleSidebar = () => {
    setIsSidebarOpen(!isSidebarOpen);
  };

  useEffect(() => {
    if (authStatus === "loading") {
      showLoader(true);
    } 
     else {
      showLoader(false);
    }
  }, [authStatus]);


  return (
    <>

      <div className="page">
        {/* <button
          type="button"
          id="sidebarCollapse"
          className="btn btn-info"
          onClick={toggleSidebar}
        >
          <i className="fas fa-align-left"></i>
          <span>Toggle Sidebar</span>
        </button> */}

        {/* <div className="row">
          <div className="col-md-12">
            <button type='button' onClick={toggleSidebar} ><IconMenu2 /></button>
          </div>
        </div> */}

        {/* <span className=" toggle" onClick={toggleSidebar}><IconMenu2 /></span> */}
        <div className="desktop-responsive d-print-none ">
          <aside
            className={`navbar navbar-vertical navbar-expand-lg navbar-transparent sidebar-border d-flex flex-column flex-shrink-0 p-0 overflow-auto 
            ${!isSidebarOpen ? "sidebar-collapsed" : ""}
              `}
            style={{
              transition: "width 0.3s ease-in-out", // Add a transition for the 'width' property
            }}
          >
            <SidebarDesktopContent isSidebarOpen={isSidebarOpen} setIsSidebarOpen={setIsSidebarOpen} />
          </aside >
        </div>

        <div className="mobile-responsive d-print-none">
          <aside className="navbar navbar-vertical navbar-expand-lg d-print-none">
            <SidebarResponsive isSidebarOpen={isSidebarOpen} />
          </aside>
        </div>


        <div className={`page-wrapper  ${isSidebarOpen ? 'custom-sidebar-expanded' : 'custom-sidebar-minimized '}`}>

          {/* <div className="row">
            <div className="col-md-12">
              <button type='button w-25' onClick={toggleSidebar} ><IconMenu2 /></button>
            </div>
          </div> */}

          <Header toggleSidebar={toggleSidebar}  {...props} />
          <div className="page-body">
            {props.component}
          </div>
          <Footer />
        </div>
      </div>

      <CLoader show={loader} />
    </>
  );
};
export default LayoutVerticalTransparent;
