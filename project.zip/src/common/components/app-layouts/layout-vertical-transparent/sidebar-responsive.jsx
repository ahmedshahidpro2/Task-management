import { useState } from "react";
import { ROUTES } from "../../../../routes/routes";
import MainMenu from "../common/main-menu";
import { logOutAction } from "../../../../app-redux/auth/authActions";
import { useAppDispatch, useAppSelector } from "../../../../app-redux/hooks";
import { selectUser } from "app-redux/auth/authSlice";

function SidebarResponsive() {
  const dispatch = useAppDispatch();
  const currentUser = useAppSelector(selectUser);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);

  const handleDropdownClick = (e) => {
    e.preventDefault();
    setIsDropdownOpen(prev => !prev)
  }

  const toggleSidebar = () => {
    setIsSidebarOpen(!isSidebarOpen);
  };

  const logout = () => {
    dispatch(logOutAction());
  }

  return (
    <>
      <div className={`container-fluid ${isSidebarOpen ? 'sidebar-open' : ''}`}>

        <button
          className="navbar-toggler"
          type="button"
          onClick={toggleSidebar}
        >
          <span className="navbar-toggler-icon" />
        </button>
        <h1 className="navbar-brand navbar-brand-autodark d-flex justify-content-lg-start ">
          {/* <a href=".">
            <img
              src="https://arpos.cloud.strahlenstudios.com/uploads/business_logos/strahlen.png"
              width="110"
              height="32"
              alt="POS"
              className="navbar-brand-image"
            />
          </a> */}
          <span className="ms-3">CSH</span>
        </h1>

        <div className={`nav-item dropdown ${isDropdownOpen ? "show" : ""}`} onClick={handleDropdownClick}>
          <span
            className="nav-link d-flex lh-1 text-reset p-0 cursor-pointer"
            data-bs-toggle="dropdown"
            aria-label="Open user menu"
            aria-expanded="true">
            <img className="avatar avatar-sm"
              src={` https://ui-avatars.com/api/?name=${currentUser?.username}`}
              alt={currentUser?.username}
            />
            <div className="d-none d-xl-block ps-2">
              <div>Haider</div>
              <div className="mt-1 small text-muted">CSH logout</div>
            </div>
          </span>
          <div className={`dropdown-menu dropdown-menu-end dropdown-menu-arrow ${isDropdownOpen ? "show" : ""}`} data-bs-popper="static">

            <a href="./settings.html" className="dropdown-item">Settings</a>

            <button className="dropdown-item" onClick={() => logout()}>
              Logout
            </button>
          </div>
        </div>

        <div className={`collapse navbar-collapse ${isSidebarOpen ? 'show' : ''}`} id="navbar-menu">
          <ul className="navbar-nav pt-lg-3">
            {ROUTES.filter((route) => route.guard).map(
              (route, i) => (
                <MainMenu route={route} isSidebarOpen={isSidebarOpen} key={i} />
              )
            )}
          </ul>
        </div>
      </div >
    </>
  );
}

export default SidebarResponsive;
