import { Link } from 'react-router-dom'
import MainMenu from '../common/main-menu'
import { ROUTES } from '../../../../routes/routes'
import { logOutAction } from '../../../../app-redux/auth/authActions'
import { useAppDispatch, useAppSelector } from '../../../../app-redux/hooks'
import { useState } from 'react'
import { selectUser } from 'app-redux/auth/authSlice'

const SidebarDesktop = ({ isSidebarOpen, setIsSidebarOpen }) => {
    const dispatch = useAppDispatch();
    const currentUser = useAppSelector(selectUser);
    const [isDropdownOpen, setIsDropdownOpen] = useState(false);

    const handleDropdownClick = (e) => {
        e.preventDefault();
        setIsDropdownOpen(prev => !prev)
    }



    const logout = () => {
        dispatch(logOutAction());
    }

    

    return (
        <>
            <h1 className="navbar-brand navbar-brand-autodark d-flex justify-content-center">
                <span>CSH</span>
            </h1>
            <div
                className={`collapse navbar-collapse  ${isSidebarOpen ? "show" : ""}`} id="sidebar-menu">
                <ul className="nav nav-pills nav-flush flex-column mb-auto text-center">
                    {ROUTES.filter((route) => route.guard).map(
                        (route, i) => (
                            <MainMenu route={route} isSidebarOpen={isSidebarOpen} setIsSidebarOpen={setIsSidebarOpen} key={i} />
                        )
                    )}
                </ul>
            </div >
            <footer>


                <ul className="text-center px-3 py-3 pb-0" >
                    <div className={`nav-item dropup ${isDropdownOpen ? "show" : ""}`} onClick={handleDropdownClick}>
                        <span
                            className="nav-link d-flex lh-1 text-reset p-0 cursor-pointer justify-content-center"
                            data-bs-toggle="dropdown"
                            aria-label="Open user menu"
                            aria-expanded="false"
                            onClick={() => {
                                setIsSidebarOpen(true);
                              }}
                        >
                            <img
                                className="avatar avatar-sm border"
                                src={` https://ui-avatars.com/api/?name=${currentUser?.email}`}
                                alt={currentUser?.email}
                            />
                            {isSidebarOpen && (
                                <div className="d-none d-xl-block ps-2">
                                    <div>{currentUser?.username}</div>
                                    <div className="mt-1 small text-muted">CSH logout</div>
                                </div>
                            )}
                        </span>

                        {isSidebarOpen && (
                        <div className={`dropdown-menu ${isDropdownOpen ? "show" : ""}`} data-bs-popper="static">
                            <div className='container'
                            >
                                <Link to="/settings/personal-settings" className="dropdown-item">
                                    Settings
                                </Link>
                                <div className="dropdown-divider" />
                                <button className="dropdown-item" onClick={() => logout()}>
                                    Logout
                                </button>

                            </div>


                        </div>
 )}
                    </div>
                </ul>
            </footer>
        </>
    )
}


export default SidebarDesktop;