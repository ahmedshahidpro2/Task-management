import { Link } from "react-router-dom";

function SubMenu({ path, route, isSidebarOpen }) {

  if (!isSidebarOpen) {
    return isSidebarOpen;
  }


  return (
    <div className="dropend">
      <>
        {route && route.length > 0 ? (
          route &&
          route.map((item, i) => (
            <Link className="dropdown-item" to={`${path}/${item.path}`} key={i}>

              {item.icon ? <item.icon /> : " "}
              <p className="mb-0">{item.title}</p>
            </Link>
          ))
        ) : (
          <Link
            className={`nav-link ${route && route.subRoutes && route.subRoutes.length > 0
              ? "dropdown-toggle"
              : ""
              } `}
            data-bs-toggle="dropdown"
            data-bs-auto-close="outside"
            role="button"
            aria-expanded="false"
          >
            <span className="nav-link-icon d-md-none d-lg-inline-block">
              {route && route.icon ? <route.icon /> : " "}
            </span>
            {route && route.title}
          </Link>
        )}

        {route && route.subRoutes && route.subRoutes.length > 0 && (
          <div className="dropdown-menu">
            {route &&
              route.subRoutes &&
              route.subRoutes.map((item) => (
                <Link to={`${path}/${item.path}`} className="dropdown-item">
                  <span className="nav-link-icon d-md-none d-lg-inline-block">
                    {item && item.icon ? <item.icon /> : " "}
                  </span>
                  {item && item.title}
                </Link>
              ))}
          </div>
        )}
      </>
    </div>
  );
}

export default SubMenu;
