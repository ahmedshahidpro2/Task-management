import { useState, useEffect } from "react";
import SubMenu from "./sub-menu";
import { Link } from "react-router-dom";
import { Icon } from '@iconify/react';

function MainMenu({ route, isSidebarOpen, setIsSidebarOpen }) {
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [foundSubRoutes, setFoundSubRoutes] = useState([]);

  useEffect(() => {
    if (route && route.subRoutes && route.subRoutes.length > 0) {
      const found = route.subRoutes.filter((item) => item.showInMenu === true);
      if (found.length > 0) {
        setFoundSubRoutes(found);
      }
    }
  }, []);

  const handleIconClick = () => {
    if (!isSidebarOpen) {
      setIsSidebarOpen(true);
    }
  };

  const handleDropdownClick = (e) => {
    e.preventDefault();
    setIsDropdownOpen(prev => !prev);
  }

  return (
    <li className={`nav-item dropdown `} onClick={handleIconClick}>
      <span
        className={`nav-link mx-1 ${(route.subRoutes.length > 0 && isSidebarOpen) ? "" : ""} ${!isSidebarOpen ? "justify-content-center sidebar-border-bottom py-2 px-2" : ""} ${isDropdownOpen ? "show" : ""}`}
        onClick={handleDropdownClick}
        data-bs-toggle="dropdown"
        data-bs-auto-close="outside"
        role="button"
        aria-expanded={`${isDropdownOpen ? false : true}`}
      >
        <span className="nav-link-icon d-md-none d-lg-inline-block">
          {route.icon ? <route.icon /> : " "}
        </span>
        {isSidebarOpen &&
          <>
            {route.subRoutes.length === 0 ? (
              <span className="nav-link-icon w-full d-flex ">
                <Link className="text-decoration-none nav-link-icon" to={route.path}>
                  <div className="reveal-text">
                    <span>{route.title}</span>
                  </div>
                </Link>
              </span>
            ) : (
              <div className="d-flex w-full text-start">
                <div className="nav-link-icon w-full d-flex m-0 reveal-text">
                  <span>{route.title}</span>
                </div>
                <div className="d-flex justify-content-end align-items-center"><Icon color="#6c757d" icon="icon-park-outline:down" rotate={isDropdownOpen ? 2 : 0} /></div>
              </div>
            )}
          </>
        }
      </span>

      {foundSubRoutes.length > 0 && (
        <div className={`dropdown-menu ${isDropdownOpen ? "show" : ""} ${!isSidebarOpen ? 'd-none' : ''}`}>
          <div className="dropdown-menu-columns">
            <div className="dropdown-menu-column">
              <SubMenu path={route.path} route={foundSubRoutes} isSidebarOpen={isSidebarOpen} />
            </div>
          </div>
        </div>
      )}
    </li>
  );
}

export default MainMenu;