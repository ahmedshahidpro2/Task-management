import React from "react";
import { ROUTES } from "../../../../routes/routes";
import MainMenu from "../common/main-menu";


function Sidebar() {

  return (
    <>
      <aside className="navbar navbar-vertical navbar-expand-lg navbar-dark d-print-none">
        <div className="container-fluid">
          <button
            className="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#sidebar-menu"
            aria-controls="sidebar-menu"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span className="navbar-toggler-icon" />
          </button>
          <h1 className="navbar-brand navbar-brand-autodark d-flex justify-content-lg-start ">
            <a href=".">
              <img
                src="https://arpos.cloud.strahlenstudios.com/uploads/business_logos/strahlen.png"
                width="110"
                height="32"
                alt="POS"
                className="navbar-brand-image"
              />
            </a>
            <span className="ms-3">CSH</span>
          </h1>

          <div className="collapse navbar-collapse" id="navbar-menu">
            <ul className="navbar-nav pt-lg-3">
              {ROUTES.filter((route) => route.guard).map(
                (route) => (
                  <>
                    <MainMenu route={route} />
                  </>
                )
              )}
            </ul>
          </div>
        </div>
      </aside>
    </>
  );
}

export default Sidebar;
