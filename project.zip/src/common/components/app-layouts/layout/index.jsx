import React from "react";
// import Footer from "./footer";
import HeaderDark from "./header_dark";

const Layout = (props) => {
  return (
    <>
      <div className="page">
        {/* <Sidebar/> */}
        <HeaderDark className={"light"} />
        <div className="page-wrapper">
          {/* <div className="page-header d-print-none"></div> */}
          <div className="page-body">
            {props.component}
          </div>
          {/* <Footer /> */}
        </div>
      </div>
    </>
  );
};
export default Layout;
