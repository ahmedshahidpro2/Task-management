import { useState } from "react";

const EmailInput = ({ onChange }) => {
  const [items, setItems] = useState([]);
  const [value, setValue] = useState("");
  const [error, setError] = useState(null);
  const [isRequired, setIsRequired] = useState(true);

  const handleKeyDown = (evt) => {
    if (["Enter", "Tab", ","].includes(evt.key)) {
      evt.preventDefault();

      const trimmedValue = value.trim();

      if (trimmedValue && isValid(trimmedValue)) {
        setItems([...items, trimmedValue]);
        setValue("");
        if (typeof onChange === "function") {
          onChange([...items, trimmedValue]);
        }
      }
    }
  };

  const handleChange = (evt) => {
    setValue(evt.target.value);
    setError(null);
    setIsRequired(evt.target.value.trim() === ''); // Check if input value is empty
  };

  const handleDelete = (item) => {
    setItems(items.filter((i) => i !== item));
    if (typeof onChange === "function") {
      onChange(items.filter((i) => i !== item));
    }
  };

  const handlePaste = (evt) => {
    evt.preventDefault();

    const paste = evt.clipboardData.getData("text");
    const emails = paste.match(/[\w\d\.-]+@[\w\d\.-]+\.[\w\d\.-]+/g);

    if (emails) {
      const toBeAdded = emails.filter((email) => !isInList(email));
      setItems([...items, ...toBeAdded]);
      setIsRequired(false); // Emails are added, input is no longer required
      if (typeof onChange === "function") {
        onChange([...items, ...toBeAdded]);
      }
    }
  };

  const isValid = (email) => {
    let validationError = null;

    if (isInList(email)) {
      validationError = `${email} has already been added.`;
    }

    if (!isEmail(email)) {
      validationError = `${email} is not a valid email address.`;
    }

    if (validationError) {
      setError(validationError);
      return false;
    }

    return true;
  };

  const isInList = (email) => {
    return items.includes(email);
  };

  const isEmail = (email) => {
    return /[\w\d\.-]+@[\w\d\.-]+\.[\w\d\.-]+/.test(email);
  };

  return (
    <>
      {error && <p className="error text-danger">{error}</p>}
      <input
        className={"input-group-text" + (error ? " has-error" : "")}
        value={value}
        placeholder="Type or paste email addresses and press `Enter`..."
        onKeyDown={handleKeyDown}
        onChange={handleChange}
        onPaste={handlePaste}
        required={isRequired} // Set the required attribute based on isRequired state
      />

      {items.map((item) => (
        <div className="input-group-text" key={item}>
          {item}
          <button
            type="button"
            className="button"
            onClick={() => handleDelete(item)}
          >
            &times;
          </button>
        </div>
      ))}
    </>
  );
};

export default EmailInput;
