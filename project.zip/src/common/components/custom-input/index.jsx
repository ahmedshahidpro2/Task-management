import React, { useState, useEffect } from "react";
import {
  getFormikErrorClass,
  getFormikErrorMessage,
} from "../../utils/app.formik.error";
import { Icon } from '@iconify/react';

const CInput = ({
  type = "text",
  autoComplete = "off",
  value = "",
  checked = null,
  className = "form-control",
  style = null,
  disabled = false,
  readOnly = false,
  arrayName = "",
  pattern,
  id,
  name,
  rows,
  placeholder,
  error,
  onChange,
  onKeyPress,
  onBlur,
  inputRef = null,
}) => {
  const [showPassword, setShowPassword] = useState(false);
  const [fieldType, setFieldType] = useState("");

  const getFieldType = (_type) => {
    if (type === "password") {
      if (showPassword === true) {
        setFieldType("text");
      } else {
        setFieldType(type);
      }
    } else {
      setFieldType(type);
    }
  };

  useEffect(() => {
    getFieldType(type);
  }, []);

  useEffect(() => {
    if (fieldType) {
      getFieldType(fieldType);
    }
  }, [showPassword]);

  return (
    <>
      {type === "textarea" ? (
        <textarea
          type="text"
          id={id}
          name={name}
          rows={rows}
          placeholder={placeholder}
          autoComplete={autoComplete}
          className={getFormikErrorClass(
            error && error,
            name,
            className,
            "is-invalid",
            arrayName
          )}
          value={value}
          onChange={onChange}
          onBlur={onBlur}
          disabled={disabled}
          readOnly={readOnly}
          ref={inputRef}
        />
      ) : (
        <input
          type={fieldType}
          id={id}
          name={name}
          value={value}
          placeholder={placeholder}
          autoComplete={autoComplete}
          className={getFormikErrorClass(
            error && error,
            name,
            className,
            "is-invalid",
            arrayName
          )}
          style={style}
          pattern={pattern}
          checked={checked}
          onChange={onChange}
          onBlur={onBlur}
          onKeyPress={onKeyPress}
          disabled={disabled}
          readOnly={readOnly}
          ref={inputRef}
        />
      )}
      {type === "password" && (
        <span
          className={getFormikErrorClass(
            error && error,
            name,
            "input-group-text",
            "c-is-invalid",
            arrayName
          )}
        >
          <a
            // href=""
            onClick={() => setShowPassword((prev) => !prev)}
            className="link-secondary"
            title="Show password"
            data-bs-toggle="tooltip"
          >
            <Icon icon="tabler:eye" 
              className="icon"
              width="24"
              height="24"
              stroke="currentColor"
            />
          </a>
        </span>
      )}
      {getFormikErrorMessage(error && error, name)}
    </>
  );
};

export default CInput;
