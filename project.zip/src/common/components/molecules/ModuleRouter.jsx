import React from "react";
import { Navigate, Route, Routes } from "react-router-dom";
import LayoutVerticalTransparent from "../app-layouts/layout-vertical-transparent";
import Layout from "../app-layouts/layout";

export function ModuleRouter(moduleRoute) {
  const { subRoutes } = moduleRoute;
  const mainPage = subRoutes?.length ? subRoutes[0].path : "";

  const getLayout = (route) => {
    switch (route?.type) {
      case "layout_vertical_transparent":
        return (
          <Route
            key={route.path}
            path={route.path + (route.pathParam || "/*")}
            element={
              <LayoutVerticalTransparent
                {...route}
                path={route.path}
                component={<route.component />}
              />
            }
          />

        );
      case "layout_horizontal":
        return (
          <Route
            key={route.path}
            path={route.path + (route.pathParam || "/*")}
            element={
              <Layout
                {...route}
                path={route.path}
                component={<route.component />}
              />
            }
          />

        );
      default:
        return (
          <Route
            key={route.path}
            path={route.path + (route.pathParam || "/*")}
            element={<route.component />
            }
          />
        );
    }
  };

  return (
    <Routes>
      {subRoutes?.map((route, i) => (
        getLayout(route)
      ))}
      <Route path={"*"} element={<Navigate to={mainPage} />} />
    </Routes>
  );
}
