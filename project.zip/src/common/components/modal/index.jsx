import React from "react";

const CustomModal = ({
    show,
    modalSize,
    children
}) => {
    return (
        <>
            <div className={`modal-backdrop  ${show ? "show" : ""}`}></div>
            <div
                className={`modal modal-blur  fade ${show ? "show" : "hide"}`}
                id="modal-verify-number"
                tabIndex={-1}
                role="dialog"
                aria-hidden="true"
                style={{ display: `${show ? "block" : "none"}` }}
            >
                <div className={`modal-dialog ${modalSize}`} role="document">
                    <div className="modal-content " >
                        {children}
                    </div>
                </div>
            </div>
        </>
    );
};

export const CustomModalHeader = ({ title, handleClose }) => {
    return (
        <div className="modal-header">
            <h5 className="modal-title">{title}</h5>
            <button
                type="button"
                className="btn-close text-reset"
                data-dismiss="modal"
                aria-label="Close"
                onClick={handleClose}
            >
                <span aria-hidden="true"></span>
            </button>
        </div>
    );
};

export const CustomModalBody = ({ children }) => {
    return <div className="modal-body">{children}</div>;
};

export const CustomModalFooter = ({ children }) => {
    return <div className="modal-footer">{children}</div>;
};

export default CustomModal;
