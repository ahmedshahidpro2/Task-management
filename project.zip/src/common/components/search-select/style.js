const styles = {
    select: {
        position: 'relative'
    },
    selectBtn: {
        position: 'relative',
        backgroundColor: '#fafafa',
        border: '1px solid #cccccc',
        borderRadius: 0,
        padding: '0.3rem 0.3rem',
        fontSize: '1rem',
        color: '#000000',
        backgroundRepeat: 'no-repeat',
        backgroundSize: '9px',
        backgroundPosition: 'right 0.3rem center',
        cursor: 'pointer'
    },
    selectDropdown: {
        listStyleType: 'none',
        position: 'absolute',
        top: '100%',
        width: '100%',
        padding: 0,
        overflow: 'hidden',
        zIndex: 100,
        background: '#fff',
        transform: 'scale(1, 0)',
        transformOrigin: 'top center',
        visibility: 'hidden',
        transition: '0.2s ease',
        border: '1px solid #cccccc',
        maxHeight: '400px !important',
        overflowY: 'auto'
    },
    selectDropdownTable: {
        margin: 0,
        padding: 0
    },
    option: {
        padding: '0rem 0.3rem',
        boxSizing: 'border-box',
        cursor: 'pointer',
        fontSize: '1rem',
        color: '#000000',
        borderBottom: '1px solid #cccccc'
    },
    optionHover: {
        background: 'rgba(70, 97, 173, 0.06)'
    },
    selectDropdownToggle: {
        visibility: 'visible',
        WebkitTransform: 'scale(1, 1)',
        transform: 'scale(1, 1)'
    },
    ssInput: {
        paddingTop: '1.625rem',
        paddingBottom: '0.625rem'
    },
    ssThW10: {
        width: '10% !important'
    },
    ssThW15: {
        width: '15% !important'
    },
    ssThW20: {
        width: '20% !important'
    },
    ssThW40: {
        width: '40% !important'
    },
    ssThW45: {
        width: '45% !important'
    },
    ssThW50: {
        width: '50% !important'
    },
    selectDropdownTh: {
        padding: '0.3rem',
        borderBottom: '1px solid #cccccc',
        whiteSpace: 'nowrap',
        overflow: 'hidden',
        textOverflow: 'ellipsis'
    },
    selectDropdownTd: {
        padding: '0.3rem',
        borderBottom: '1px solid #cccccc',
        whiteSpace: 'nowrap',
        overflow: 'hidden',
        textOverflow: 'ellipsis'
    },
    arTable: {
        display: 'flex',
        flexFlow: 'column',
        width: '100%'
    },
    arThead: {
        flex: '0 0 auto',
        paddingRight: '8px'
    },
    arTbody: {
        flex: '1 1 auto',
        display: 'block',
        overflowY: 'auto',
        overflowX: 'hidden'
    },
    tr: {
        width: '100%',
        display: 'table',
        tableLayout: 'fixed'
    },
    formFloatingLabel: {
        position: 'absolute !important',
        top: 0,
        left: 0,
        width: '100%',
        pointerEvents: 'none',
        fontSize: '1rem',
        color: '#999999',
        transition: '0.2s ease all'
    },
    formFloatingInput: {
        padding: '1rem 0.5rem 0.5rem',
        border: 'none',
        borderBottom: '1px solid #cccccc',
        width: '100%',
        fontSize: '1rem',
        color: '#000000',
        background: 'transparent',
        outline: 'none',
        transition: '0.2s ease all'
    },
    formFloatingInputFocus: {
        borderBottom: '2px solid #4761ad'
    },
    formFloatingInputError: {
        borderBottom: '2px solid #ff0000'
    },
    formFloatingInputValid: {
        borderBottom: '2px solid #00ff00'
    }
};

module.exports = styles;