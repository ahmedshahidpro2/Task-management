/* eslint-disable react-hooks/exhaustive-deps */
import React, {
  useState,
  useRef,
  useEffect,
  useMemo,
  useCallback,
} from "react";
import "./select.css";
import {
  getFormikErrorClass,
  getFormikErrorMessage,
} from "../../utils/app.formik.error";

const PAGE_SIZE = 30; // number of items to load at once
let start = 0;
const SCROLL_SIZE = 3;
let end = PAGE_SIZE;

const CustomDropdown = ({
  id,
  selectedValue,
  optionLabel = "label",
  options = [],
  columns = [],
  searchAttributes = ["value"],
  disabled = false,
  inputRef = null,
  searchStartsWith = false,
  onSelect,
  name,
  error,
}) => {
  const [dropdown, setDropdown] = useState(false);
  const [scroll, setScroll] = useState(false);
  const [search, setSearch] = useState("");
  const [value, setValue] = useState("");
  const [filteredOptions, setFilteredOptions] = useState([]);
  const [originalOptions, setOriginalOptions] = useState([]);
  const [finalArray, setFinalArray] = useState([]);
  const [selectedIndex, setSelectedIndex] = useState(0);
  const dropdownRef = useRef(null);
  const searchInputRef = useRef(null);
  const selectDropdownRef = useRef(null);
  const [selectedItem, setSelectedItem] = useState(null);

  const handleOpenDropdown = useCallback(
    (event) => {
      if (event.target.id === `dropdown-input-${id}`) {
        setDropdown(true);
      }
    },
    [id]
  );

  const handleClickOutside = useCallback(
    (event) => {
      if (
        dropdownRef.current &&
        !dropdownRef.current.contains(event.target) &&
        event.target.id !== `dropdown-input-${id}`
      ) {
        setDropdown(false);
      }
    },
    [id]
  );

  const handleFocus = useCallback(
    (event) => {
      setTimeout(() => {
        if (
          inputRef &&
          inputRef.current &&
          inputRef.current === document.activeElement &&
          event.target.id === `dropdown-input-${id}`
        ) {
          setDropdown(true);
        }
      }, 50);
    },
    [id]
  );

  useEffect(() => {
    document.addEventListener("click", handleOpenDropdown);
    return () => {
      document.removeEventListener("click", handleOpenDropdown);
    };
  }, [handleOpenDropdown]);

  useEffect(() => {
    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [handleClickOutside]);

  useEffect(() => {
    document.addEventListener("focus", handleFocus, true);
    return () => {
      document.removeEventListener("focus", handleFocus, true);
    };
  }, [handleFocus]);

  useEffect(() => {
    setOriginalOptions(options);
    setFilteredOptions(options);
  }, [options]);

  useEffect(() => {
    if (selectedValue?.optionType === "default") {
      setValue(selectedValue.name);
      setSearch("");
    } else {
      if (selectedValue && selectedValue[optionLabel])
        setValue(selectedValue && selectedValue[optionLabel]);
    }
  }, [selectedValue]);

  useEffect(() => {
    setFinalArray(getItems(filteredOptions, 0, end));
  }, [filteredOptions]);

  useEffect(() => {
    if (dropdown) {
      if (search) {
        handleSearchString(search);
      }
      if (searchInputRef.current) {
        searchInputRef.current.focus();
        searchInputRef.current.select();
      }
    }
  }, [dropdown]);

  useEffect(() => {
    if (scroll) {
      const element = document.querySelector(".table-active"); // Select the element
      const parent = document.querySelector(".selectDropdown"); // Select the parent container
      if (element && parent) {
        parent.scrollTop = element.offsetTop;
      }
      setScroll(false);
    }
  }, [scroll]);

  useEffect(() => {
    if (selectedIndex > -1) {
      const element = document.querySelector(".table-active");
      if (element) {
        element.scrollIntoView({ behavior: "instant", block: "nearest" });
      }
    }
    if (selectedIndex === -1) {
      setSelectedIndex(0);
    }
  }, [selectedIndex]);

  const setOption = (item) => {
    if (item?.optionType === "default") {
      setValue(item["name"]);
    } else {
      setValue(item[optionLabel]);
    }
    onSelect(item);
    setSelectedItem(item);
    setDropdown(false);
  };

  // generate an array of items based on the start and end indices
  function getItems(array, start, end) {
    if (array === null) {
      return [];
    }
    return array.slice(start, end);
  }

  useEffect(() => {
    if (selectedItem !== null) {
      const element = document.querySelector(".table-active");
      if (element) {
        const parent = document.querySelector(".selectDropdown");
        const parentRect = parent.getBoundingClientRect();
        const elementRect = element.getBoundingClientRect();
        if (
          elementRect.bottom > parentRect.bottom ||
          elementRect.top < parentRect.top
        ) {
          element.scrollIntoView({ behavior: "instant", block: "nearest" });
        }
      }
    }
  }, [selectedItem]);

  function handleScroll() {
    const container = document.getElementById("ar-scroll-tbody");
    const containerHeight = container.clientHeight;
    const contentHeight = container.scrollHeight;
    const scrollPosition = container.scrollTop;
    const buffer = 100; // number of pixels from the bottom to start loading more items

    // check if user has scrolled to the bottom of the page
    if (contentHeight - containerHeight - scrollPosition < buffer) {
      // update start and end indices to fetch the next batch of items
      start = end;
      end += PAGE_SIZE;
      // concatenate new items to the temporary array
      const newItems = getItems(originalOptions, start, end);
      setFinalArray(finalArray.concat(newItems));
    }
  }

  const handleSearch = (e) => {
    setSearch(e.target.value);
    if (!e.target.value) {
      setFilteredOptions(options);
      return;
    }

    if (!originalOptions.length) {
      setFilteredOptions(options);
      return;
    }

    const searchTerms = e.target.value.split(",").map((term) => term.trim());
    let filtered = originalOptions;
    searchTerms.forEach((term) => {
      filtered = filtered.filter((option) => {
        if (searchStartsWith) {
          return searchAttributes.some((attribute) => {
            return (
              typeof option[attribute] === "string" &&
              option[attribute].toLowerCase().startsWith(term.toLowerCase())
            );
          });
        } else {
          return searchAttributes.some((attribute) => {
            return (
              typeof option[attribute] === "string" &&
              option[attribute].toLowerCase().includes(term.toLowerCase())
            );
          });
        }
      });
    });
    setFilteredOptions(filtered);
  };

  const handleSearchString = (searchString) => {
    const event = {
      target: {
        value: searchString,
      },
    };
    handleSearch(event);
  };

  const handleKeyDownInput = (e) => {
    if (e.key === "Enter") {
      e.preventDefault();
      if (dropdown) {
        setOption(filteredOptions[selectedIndex]);
      } else {
        setDropdown((prev) => !prev);
      }
    }
  };

  const handleKeyDown = (e) => {
    if (e.shiftKey && e.keyCode === 9) {
      // "Shift+Tab" key combination
      const inputs = Array.from(
        document.querySelectorAll("input, select, textarea")
      );
      const activeIndex = inputs.findIndex(
        (input) => input === document.activeElement
      );
      if (activeIndex > 0) {
        const prevInput = inputs[activeIndex - 1];
        if (prevInput) {
          prevInput.focus();
        }
      }
      e.preventDefault();
    } else if (e.keyCode === 192) {
      // keyCode for "`" key
      const inputs = Array.from(
        document.querySelectorAll("input, select, textarea")
      );
      const activeIndex = inputs.findIndex(
        (input) => input === document.activeElement
      );
      if (activeIndex > 0) {
        const prevInput = inputs[activeIndex - 1];
        if (prevInput) {
          prevInput.focus();
        }
      }
      e.preventDefault();
    } else if (e.key === "Enter") {
      e.preventDefault();
      if (dropdown) {
        if (filteredOptions.length > 0) {
          setOption(filteredOptions[selectedIndex]);
        } else {
          setOption(originalOptions[selectedIndex]);
        }
      } else {
        setDropdown((prev) => !prev);
      }
    } else if (e.key === "Tab") {
      e.preventDefault();
      // if (!dropdown) {
      setDropdown((prev) => !prev);
      // }
    } else if (e.key === "ArrowDown") {
      e.preventDefault();
      setSelectedIndex((prev) => (prev + 1) % filteredOptions.length);
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      setSelectedIndex(
        (prev) => (prev - 1 + filteredOptions.length) % filteredOptions.length
      );
    } else if (e.key === "PageDown") {
      e.preventDefault();
      setSelectedIndex((prev) => (prev + SCROLL_SIZE) % filteredOptions.length);
      setScroll(true);
    } else if (e.key === "PageUp") {
      e.preventDefault();
      setSelectedIndex(
        (prev) =>
          (prev - SCROLL_SIZE + filteredOptions.length) % filteredOptions.length
      );
      setScroll(true);
    }
  };

  useEffect(() => {
    if (dropdown) {
      setSelectedIndex(0);
    }
  }, [search]);

  return useMemo(() => {
    return (
      <div className="customDropdown" ref={dropdownRef}>
        <input
          id={`dropdown-input-${id}`} // Assign a unique ID based on the id prop
          className={getFormikErrorClass(
            error && error,
            name,
            "form-select ss-input",
            "border border-danger is-invalid"
          )}
          type="text"
          placeholder="Search"
          value={value}
          onClick={() => setDropdown((prev) => !prev)}
          onKeyDown={handleKeyDownInput}
          readOnly={true}
          ref={inputRef}
          tabIndex={0}
        />
       { getFormikErrorMessage(
            error && error,
            name
          )}
        <div className="select" ref={selectDropdownRef}>
          {dropdown && (
            <div className={`selectDropdown ${dropdown ? "toggle" : ""}`}>
              <input
                className="form-select ss-input"
                type="text"
                placeholder="Search"
                value={search}
                onChange={handleSearch}
                onKeyDown={handleKeyDown}
                disabled={disabled}
                ref={searchInputRef}
              />
              {finalArray && finalArray.length === 0 ? (
                <p className="text-center text-dark mb-0"> No data found</p>
              ) : (
                <div className="table-container">
                  <table className={`table table-bordered`}>
                    <thead className="tableFixHead ar-thead text-dark">
                      <tr className="disabled ar-tr ">
                        {columns &&
                          columns.map((head, i) => (
                            <th key={i} className={head.className}>
                              {head.label}
                            </th>
                          ))}
                      </tr>
                    </thead>
                    <tbody
                      id="ar-scroll-tbody"
                      className="ar-tbody"
                      onScroll={handleScroll}
                    >
                      {finalArray &&
                        finalArray.map((item, i) =>
                          item?.optionType === "default" && i === 0 ? (
                            <tr
                              className={`option py-1 ar-tr disabled`}
                              key={i}
                              onClick={() => setOption(item)}
                            >
                              <td
                                colSpan={columns?.length + 1}
                                className="py-0 text-center w-100"
                                key={i}
                              >
                                {item?.name || "Please select"}
                              </td>
                            </tr>
                          ) : (
                            <tr
                              className={`option py-1 ar-tr ${
                                selectedIndex === i ? "table-active" : ""
                              }`}
                              key={i}
                              onClick={() => setOption(item)}
                            >
                              {columns &&
                                columns.map((head, i) => (
                                  <td
                                    className={`py-0 ${head.className}`}
                                    key={i}
                                    title={item[head.name]}
                                  >
                                    {head && head.sub_name
                                      ? item[head.name][head.sub_name]
                                      : item[head.name]}
                                  </td>
                                ))}
                            </tr>
                          )
                        )}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    );
  }, [id, dropdown, finalArray, selectedIndex, search, error]); // Add id and other dependencies here
};

export default CustomDropdown;
