
import { AuthRoute } from "modules/auth/auth.routes";

import { TaskRoute } from "../modules/task/task.routes";


export const ROUTES = [
  AuthRoute,
  // MeetingRoute,
 
  TaskRoute,
];
