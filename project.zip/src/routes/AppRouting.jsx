import React from "react";
import { BrowserRouter, Navigate, Route, Routes } from "react-router-dom";
import { ROUTES } from "./routes";
import { RouteGuard } from "../modules/auth/components/RouteGuard";
import { useAppSelector } from "../app-redux/hooks";
import { isLogin } from "../app-redux/auth/authSlice";
import NotFound from "../modules/common/not-found";

const AppRouting = () => {
  const isLoggedIn = useAppSelector(isLogin);
  // const baseUrl = document.getElementsByTagName("base")[0].getAttribute("href");
  
  return (
    //  <BrowserRouter basename={baseUrl}>
    <BrowserRouter>
      <Routes>
        {ROUTES.map((route, i) => (
          <Route
            key={i}
            path={route.path + "/*"}
            element={
              route.guard ? (
                <RouteGuard path={route.path} redirectPath="/auth">
                  {<route.component />}
                </RouteGuard>
              ) : (
                <>
                  {!isLoggedIn ? (
                    <>
                      <route.component />
                    </>
                  ) : (
                    <Navigate replace to="/task/list" />
                  )}
                </>
              )
            }
          ></Route>
        ))}

        <Route path="/" element={<Navigate replace to="/task/list" />} />
        <Route path="*" element={<NotFound />} />
        {/* <Route path="calendar/shared/:userId/:userName" element={<SlotView/>}/>
        <Route path="calendar/shared/:userId/:userName/:slotId" element={<SlotAccept/>}/>
        <Route path="meeting/Participants-notes-meeting-space/:id" element={<ParticipantNoteSpace/>}/>
         */}
      </Routes>
    </BrowserRouter>
  );
};

export default AppRouting;
