import TaskPage from "./task-creation";
import { TaskModule } from "./task-module";


import { Icon } from "@iconify/react";

export const TaskRoute = {

  title: "Task Dashboard",
  path: "/task",
  icon:()=> <Icon icon="mdi:virtual-meeting" width="1.4rem" height="1.4rem"  />,
  component: TaskModule,
  type: "layout_vertical_transparent",
  //Icon:<Icon icon="pixelarticons:notes-plus"  />,
  guard: true,
  subRoutes: [
    {
      component: () =>  <TaskPage/>,
      path: "list",
      title: "Task List",
      type: "layout_vertical_transparent",
      subRoutes: [],
      showInMenu: true,
    },

  ],
};


