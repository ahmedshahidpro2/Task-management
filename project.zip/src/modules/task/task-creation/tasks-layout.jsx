
import { useState, useEffect } from "react";
import { Icon } from "@iconify/react";
import { useAppDispatch, useAppSelector } from "../../../app-redux/hooks";
import { selectUser } from "../../../app-redux/auth/authSlice";
import CLoader from "../../../common/components/loader";
import moment from 'moment';
import { TaskRetrievedData, addedTaskResponse, deletedTaskResponse, updatedTaskResponse } from "../../../app-redux/task/taskSlice";
import { deleteTask, getAllTask } from "../../../app-redux/task/taskActions";
import UpdatetaskModal from "./task-update-button-modal";

export default function Tasklayout() {

  const currentUser = useAppSelector(selectUser);
  const taskAdded = useAppSelector(addedTaskResponse);
  const taskUpdated = useAppSelector(updatedTaskResponse);
  const taskDeleted = useAppSelector(deletedTaskResponse);
  const dispatch = useAppDispatch();


  const [data, setData] = useState([]);
  const [addModel, setAddModel] = useState(false);
  const [myObj, setMyObj] = useState({});

  const model = {
    id: currentUser.id,
  };

  useEffect(() => {
    dispatch(getAllTask(model));
  }, [taskAdded, taskUpdated, taskDeleted]);

  const taskData = useAppSelector(TaskRetrievedData);

  useEffect(() => {
    setData(taskData);
    console.log("taskData", taskData);
  }, [taskData]);



  const handleDeletionClick = (id) => {
    console.log(id);
    dispatch(deleteTask({ taskID:id }));
  }

  const handleUpdationClick = (task) => {
    console.log("Task:\n", task);
    setMyObj(task);
    setAddModel(true);
  }

  return (
    <>

      {
        data === null ? <div> <CLoader /></div> :
          (data.length > 0) ? (
            data.map((item) => (
              <TaskCard key={item.taskid} task={item}
                onDelete={handleDeletionClick}
                onUpdate={handleUpdationClick} />
            ))
          ) : (
            <div>Nothing to show here ........</div>
          )
      }

      {
        addModel &&
        <UpdatetaskModal show={addModel} setShow={setAddModel} task={myObj} />
      }
    </>
  );
}

function TaskCard({ task, onDelete, onUpdate }) {
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);

  const handleDropdownClick = (e) => {
    e.preventDefault();
    setIsDropdownOpen((prev) => !prev);
  };

  const handleDeletionClick = () => {
    onDelete(task._id);
  };

  const handleUpdationClick = () => {
    onUpdate(task);
  };

  return (
    <>
      <div className="container-fluid">
        <div className="col-md-12 p-3 ">
          <div className="card">
            <div className="card-header">
              <div>
                <div className="row align-items-center">
                  <div className="col-auto">
                    <span className="avatar">
                      {/* <img
                        className="avatar avatar-sm border"
                        src={`https://ui-avatars.com/api/?name=${currentUser?.email}`}
                        alt={currentUser?.email}
                      /> */}
                    </span>
                  </div>

                  <div className="col">
                    <div className="card-title">
                      Task Title : <span id="Project_id">{task.taskTitle}</span>
                    </div>
                    <div className="card-subtitle">{task._id}</div>
                  </div>
                </div>
              </div>

              <div className="card-actions">
                <div
                  className={`nav-item dropdown ${isDropdownOpen ? "show" : ""}`}
                  onClick={handleDropdownClick}
                >
                  <span
                    className="nav-link d-flex lh-1 text-reset p-0 cursor-pointer"
                    data-bs-toggle="dropdown"
                    aria-label="Open user menu"
                    aria-expanded="true"
                  >
                    <div className=" d-xl-block ps-2">
                      <Icon icon="simple-line-icons:options-vertical" width="1.2em" height="1.2em" />
                    </div>
                  </span>

                  <div
                    className={`dropdown-menu dropdown-menu-end dropdown-menu-arrow ${isDropdownOpen ? "show" : ""}`}
                    data-bs-popper="static">

                    <button className="dropdown-item" onClick={handleUpdationClick}>
                      Update
                    </button>

                    <button className="dropdown-item text-danger" onClick={handleDeletionClick}>
                      Delete
                    </button>

                  </div>
                </div>
              </div>
            </div>

            <div className="row g-0">
              <div className="col-auto">
                <div className="card-body">
                  <div className="row">
                    <div className="col-md">

                      <div className="mt-3 list-inline list-inline-dots mb-0 text-muted ">
                        <span className="fw-bold text-primary ">Task Description:&nbsp;</span>
                        <span>{task.taskDescription} </span>
                      </div>

                      <div className="mt-3 list-inline list-inline-dots mb-0 text-muted ">
                        <span className="fw-bold text-primary ">Created At:&nbsp;</span>
                        <span id="Project_time">{moment(task.creationTime).format("YYYY-MM-DD HH:mm:ss")}</span>
                      </div>

                      <div className="mt-3 list-inline list-inline-dots mb-0 text-muted ">
                        <span className="fw-bold text-primary ">Scheduled Date:&nbsp;</span>
                        <span id="Project_time">{moment(task.endDatetime).format("YYYY-MM-DD HH:mm:ss")}</span>
                      </div>

                      <div className="mt-3 badges">
                        <p className="fw-bold ">
                          Status: &nbsp;
                          <span id="meeting_status" className="text-success">
                            {task.taskStatus === '1' ? <span>Calendar-Scheduled</span> : <span>Manually Created</span>}
                          </span>
                        </p>
                      </div>

                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
