import CInput from "common/components/custom-input";
import { useFormik } from "formik";
import React, { useEffect, useState } from "react";
import CustomModal, {
  CustomModalHeader,
  CustomModalBody,
  CustomModalFooter,
} from "common/components/modal";
import moment from 'moment';
import { taskValidation } from "../../common/validation";
import { useAppDispatch } from "../../../app-redux/hooks";
import { addTask } from "../../../app-redux/task/taskActions";


const InitValues = {
  taskTitle: "",
  reportingDate: "",
  time: "",
  taskDescription:"",
};

const TaskModal = ({ show, setShow }) => {

  const dispatch = useAppDispatch();

  const [isFormik, setIsFormik] = useState(false);
  const [messages, setMessages] = useState({});

  
 

  let modal;
  const formik = useFormik({
    initialValues: InitValues,

    validationSchema: taskValidation(),

    onSubmit: (values) => {

      const dateTimeString = `${values.reportingDate} ${values.time}`;
      //const dateTime = new Date(dateTimeString);
      console.log("dateTimeString", dateTimeString);
      const dateTime = moment(dateTimeString, 'YYYY-MM-DD HH:mm');
      // Convert the dateTime to UTC
      const utcDateTime = dateTime.utc();
      // Format the UTC date-time string
      const utcDateTimeString = utcDateTime.format('YYYY-MM-DDTHH:mm:ss') + 'Z';  
      console.log('UTC Date-Time:', utcDateTimeString);
      
      const currentDate = moment().utc().format('YYYY-MM-DDTHH:mm:ss') + 'Z';;

      console.log('Current Date and Time:', currentDate);

      modal = {
        MeetingBody: {
          taskTitle: values.taskTitle,
          endDatetime: utcDateTimeString,
          taskDescription: values.taskDescription,
          creationTime:currentDate,
          taskStatus:0,
        }
      }
      console.log(modal);
      dispatch(addTask(modal));
      handleClose();
    },
  });

  useEffect(() => {
    setIsFormik(true)
  }, [formik.errors]);


  const handleClose = () => {
    setShow(false);
  };


  return (
    <CustomModal show={show} width={30} handleClose={handleClose}>
      <form onSubmit={formik.handleSubmit} onReset={formik.resetForm}>

        <CustomModalHeader
          title={
            <>
              Task Creation
            </>
          }
          handleClose={handleClose}
        />

        <CustomModalBody>
          <div className="row">

            <label className="form-label mt-2">Task Title:</label>
            <CInput
              id="taskTitle"
              name="taskTitle"
              value={formik.values.taskTitle}
              placeholder="Task Title Here"
              onChange={formik.handleChange}

              onBlur={formik.handleBlur}
              error={
                isFormik
                  ? { type: "formik", error: formik && formik }
                  : { type: "server", error: messages }
              }
              type="text"
            />

            <label className="form-label mt-2">End Date</label>
            <CInput
              id="reportingDate"
              name="reportingDate"
              value={formik.values.reportingDate}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
              error={
                isFormik
                  ? { type: "formik", error: formik && formik }
                  : { type: "server", error: messages }
              }
              type="date"
            />

            <label className="form-label mt-2">End Time</label>
            <CInput
              id="time"
              name="time"
              value={formik.values.time}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
              error={
                isFormik
                  ? { type: "formik", error: formik && formik }
                  : { type: "server", error: messages }
              }
              type="time"
            />

            <label className="form-label mt-2">Task Description:</label>
            <CInput
              id="taskDescription"
              name="taskDescription"
              value={formik.values.taskDescription}
              placeholder="Task Description Here"
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
              error={
                isFormik
                  ? { type: "formik", error: formik && formik }
                  : { type: "server", error: messages }
              }
              type="textarea"
            />

           

          </div>
        </CustomModalBody>

        <CustomModalFooter>
          <div className="mb-3 col-xl-12 d-flex justify-content-end">
            <button type="submit" className="btn btn-success" name="Save">
              SCHEDULE
            </button>
          </div>
        </CustomModalFooter>
      </form>
    </CustomModal >
  )
}

export default TaskModal;





