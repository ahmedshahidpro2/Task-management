
import { useAppDispatch, useAppSelector } from '../../../app-redux/hooks';
import { useEffect, useState } from 'react';
import TaskButton from './task-creation-button';
import Tasklayout from './tasks-layout';

export default function TaskPage() {

  const dispatch = useAppDispatch();
  
  return (
    <>
      <div className="container-fluid ">
       
        <TaskButton />

        <ul className="nav nav-bordered mb-4">
          <li className="nav-item">
            <a id="note-link-1" className="nav-link active"

              onClick={() => {
                document.getElementById("note-link-1").classList.add("active");
                document.getElementById("note-link-2").classList.remove("active");

              }} >View Task </a>
          </li>

        
        </ul>

      </div>

      <div>
        <div className="row g-4  ">
          <Tasklayout />
        </div>
      </div>
    </>
  )
}
