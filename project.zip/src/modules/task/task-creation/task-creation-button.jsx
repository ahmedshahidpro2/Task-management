import { Icon } from '@iconify/react';
import React, { useState } from "react";
import TaskModal from './task-creation-button-modal';




const TaskButton = () => {

  const [addModel, setAddModel] = useState(false);
  
  const handleClick = () => {
    setAddModel(true);
  }

  return (

    <>
      <div className="row g-2 align-items-center">

        {/* Page title actions */}
        <div className="col-auto ms-auto d-print-none">
          <div className="btn-list">

            <button onClick={handleClick} className="btn btn-primary d-sm-inline-block" data-bs-toggle="modal" data-bs-target="#project-report">
              <Icon icon="bx:plus" height="25" />
              Create new Task
            </button>
          </div>
        </div>
      </div>

      {addModel &&
        <TaskModal show={addModel} setShow={setAddModel} />
      }

    </>
  )
}

export default TaskButton;



