import React from 'react';
import { useLocation } from 'react-router-dom';

function CatchCode() {
  const location = useLocation();
  const searchParams = new URLSearchParams(location.search);
  const code = searchParams.get('code');

  // Use the code parameter here
  console.log(code);

  return (
    <div>
      <h1>Code: {code}</h1>
    </div>
  );
}

export default CatchCode;
