//validation
import { date, number, object, string } from "yup";

const handlethis = () => {
  let b = false;
  return b;
}

export const offcanvasValidation = (isChecked) => {
  // console.log(description.value);
  // Define the validation schema
  const validationSchema = object({
    eventTitle: string().required("This field is required."),
    description: string().required("This field is required."),
    meetingTitle: isChecked ? string().required("This field is required.") : string(),
    submeetingTitle: isChecked ? string().required("This field is required") : string(),
    emailParticipant: isChecked ? string().required("This field is required.") : string(),
    // emailparticipant: isChecked  ? ( handlethis === true ? string().required("This field is required."):string().required("This email is not correct  required.")): string(),

  });

  return validationSchema;
};


// export const offcanvasValidation = (isChecked) => {
//     console.log("ischecked validation", isChecked);

//     const validationSchema = {
//         eventtitle: string().required("This field is required."),
//         description: string().required("This field is required."),
//     };
//     if (isChecked) {
//         validationSchema.meetingtitle = string().required("This field is required.");
//         validationSchema.emailparticipant = string().required("This field is required.");
//     }
//     return (
//         {
//             validationSchema
//         }
//     )


// };
const emailRegex = /^[\s]*(([^@,\s]+)@[\w\s\.-]+)((,[\s]*)?([^@,\s]+)@[\w\s\.-]+)*[\s]*$/;

export const taskValidation = () => {
  const validationSchema = object({

    taskTitle: string().required("This field is required."),
    taskDescription: string().required("This field is required."),
    reportingDate: date().required("Date is Required."),
    time: string().required("Time is Required."),
  });

  return validationSchema;
};
export const Projectvalidation = object({

  ProjectTitle: string().required("This field is required."),

});


export const project_Meeting_JOIN_URl_Validation = object({

  message: string().required("This field is required."),

});


export const notesValidation = () => {

  const validationSchema = object({
    text: string().required("This field is required."),
  });
  return validationSchema;
};

