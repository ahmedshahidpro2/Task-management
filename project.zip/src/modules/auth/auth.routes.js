import Signin from "./signin";
import { AuthModule } from "./AuthModule";
import signup from "./signup";


export const AuthRoute = {
  title: "Auth",
  path: "/auth",
  // icon: HomeIcon,
  component: AuthModule,
  guard: false,
  subRoutes: [
    { path: "signin", component: Signin, },
    { path: "signup", component: signup, },
   
  ],
};
