import { object, string } from "yup";



export const signupFormValidation = object({
    email: string().email().required("This field is required."),
    password: string()
        .matches(/^(?=.*[A-Z])(?=.*[!@#$%^&*]).{8,}$/, "Password must be at least 8 characters long, contain at least one uppercase letter, and one special character.")
        .required("No password provided."),
    username: string().required("User Name is required ")
});