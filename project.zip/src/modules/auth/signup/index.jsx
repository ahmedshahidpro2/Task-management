import React, { useEffect, useState } from "react";
import { useFormik } from "formik";
import CInput from "common/components/custom-input";
import { useAppDispatch, useAppSelector } from "app-redux/hooks";
import { signupFormValidation } from "./validation";
import { signUpAction } from "app-redux/auth/authActions";
import { resetErrorAction, selectAuthError, SignUpActionResponse, selectStatus } from "app-redux/auth/authSlice";

import CLoader from "common/components/loader";
import { setTheme } from "common/utils/app.util";
import { useThemeState } from "../../../app-redux/hooks/useThemeState";
import logo from '../logo.png';
import { Link } from "react-router-dom";


function Signup() {

  const dispatch = useAppDispatch();
  const [messages, setMessages] = useState({});
  const [isFormik, setIsFormik] = useState(true);
  const [message, setMessage] = useState(null);
  const [disabled, setDisabled] = useState(false);
  const [loader, showLoader] = useState(false);
  const [authMessage, setauthMessage] = useState("");
 
  const messageOfAuth = useAppSelector(SignUpActionResponse);
  

  useEffect(() => {
    if (messageOfAuth) {
      console.log("messageOfAuth");
      setauthMessage(messageOfAuth)
      showLoader(false)
    }

  }, [messageOfAuth])


  let error = useAppSelector(selectAuthError);

  const authStatus = useAppSelector(selectStatus);

  const { themeState } = useThemeState();

  const formik = useFormik({
    initialValues: {
      username: "",
      email: "",
      password: "",
    },

    validationSchema: signupFormValidation,
    onSubmit: async (values) => {
      const model = {
        username: values.username,
        email: values.email,
        password: values.password,
      };

      console.log(model.username);
      console.log(model.email);
      console.log(model.password);
      debugger
      dispatch(signUpAction(model));
      showLoader(true)
    }


  });

  // useEffect(() => {
  //   if (authStatus === "loading") showLoader(true)
  //   else showLoader(false)
  // }, [authStatus]);

  useEffect(() => {
    dispatch(resetErrorAction());
  }, []);

  useEffect(() => {

    setTheme(themeState);

  }, [themeState])


  useEffect(() => {
    if (error && error.error) {
      let err = error.error;
      if (err && (typeof err) == "string") {
        setMessages(null);
        setMessage({ error_msg: err, status: "danger" });
        setIsFormik(false)
      }
    } else setMessages(null);
  }, [error]);

  useEffect(() => {
    setIsFormik(true)
  }, [formik.errors]);


  return (
    <>
      <div className="d-flex flex-column">
        <div className="page page-center">
          <div className="container-tight py-4">
            <div className="text-center mb-4">
              <a href="." className="navbar-brand navbar-brand-autodark"><img src={logo} height={86} alt /></a>
            </div>
            <form
              className="card card-md"
              onSubmit={formik.handleSubmit}
              autoComplete="off"
            >
              <div className="card-body">

                <h2 className="card-title text-center mb-4">
                  Create New account
                </h2>

                {/* userName */}
                <div className="row mb-3">
                  {message &&
                    <Alert title={message.error_msg} type={message.status} />}
                  <div className="col-md-12 col-xl-12">
                    <label className="form-label">User Name</label>
                    <CInput
                      id="username"
                      name="username"
                      value={formik.values.username}
                      onChange={formik.handleChange}
                      onBlur={formik.handleBlur}
                      error={isFormik ? { type: "formik", error: formik && formik } : { type: "server", error: messages }}
                      type="text"
                    />
                  </div>
                </div>


                {/* Email */}
                <div className="row mb-3">
                  {message &&
                    <Alert title={message.error_msg} type={message.status} />}
                  <div className="col-md-12 col-xl-12">
                    <label className="form-label">Email</label>

                    <CInput
                      id="email"
                      name="email"
                      value={formik.values.email}
                      onChange={formik.handleChange}
                      onBlur={formik.handleBlur}
                      error={isFormik ? { type: "formik", error: formik && formik } : { type: "server", error: messages }}
                      type="email"
                    />

                  </div>
                </div>
                {/* Password */}
                <div className="row mb-3">
                  <div className="col-md-12 col-xl-12">
                    <label className="form-label">Password

                    </label>
                    <div className="input-group">
                      <CInput
                        id="password"
                        name="password"
                        value={formik.values.password}
                        onChange={formik.handleChange}
                        onBlur={formik.handleBlur}
                        error={isFormik ? { type: "formik", error: formik && formik } : { type: "server", error: messages }}
                        type="password"
                      />
                    </div>
                  </div>
                </div>



                <div className="form-footer">
                  <button type="submit" className={`btn btn-primary w-100 ${disabled ? "disabled" : ""}`}>
                    Sign Up
                  </button>
                </div>

                <div className="form-footer">
                  <div className="col-md-12 col-xl-12">
                    <label className="form-label">Already have account &nbsp;
                      <Link to="/auth/signin"><strong>Sign in</strong></Link></label>
                  </div>
                </div>
               
                <div className="text-success">*{authMessage}</div>

              </div>


            </form>
          </div>
        </div>
      </div>
      <CLoader show={loader} />
    </>
  );
}
export default Signup;

