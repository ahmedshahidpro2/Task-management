import React, { useEffect, useState } from "react";
import { useFormik } from "formik";
import CInput from "common/components/custom-input";
import { useAppDispatch, useAppSelector } from "app-redux/hooks";
import { signinFormValidation } from "./validation";
import { loginAction } from "app-redux/auth/authActions";
import { resetErrorAction, selectAuthError, selectStatus } from "app-redux/auth/authSlice";

import CLoader from "common/components/loader";
import { setTheme } from "common/utils/app.util";
import { useThemeState } from "../../../app-redux/hooks/useThemeState";
// import { selectLoginIDStatus } from "../../../app-redux/auth/authSlice";
import { Link } from "react-router-dom";
import Signup from "../signup";
import screenshotImage from './Screenshot.jpg'; // Assuming Screenshot.jpg is in the same directory as this file
import logo from '../logo.png';


function Signin() {

  const dispatch = useAppDispatch();
  const [messages, setMessages] = useState({});
  const [isFormik, setIsFormik] = useState(true);
  const [message, setMessage] = useState(null);
  const [disabled, setDisabled] = useState(false);
  const [loader, showLoader] = useState(false)
  const [userData, setUserData] = useState("")

  let error = useAppSelector(selectAuthError);
  const authStatus = useAppSelector(selectStatus);
  // const LoginStatus = useAppSelector(selectLoginIDStatus)
  const { themeState } = useThemeState();


  const formik = useFormik({
    initialValues: {
      email: "",
      password: "",
    },
    validationSchema: signinFormValidation,
    onSubmit: (values) => {
      const model = {
        email: values.email,
        password: values.password,
      };
      console.log(model.email);
      console.log(model.password);
      dispatch(loginAction(model));
    },
  });

  useEffect(() => {
    const items = JSON.parse(localStorage.getItem('csh-auth-user'));
    if (items) {
      setUserData(items);
    }

    console.log("authStatus", authStatus)
    // if (authStatus === "loading") showLoader(true)
    // else showLoader(false)
  }, [authStatus]);

  useEffect(() => {
    dispatch(resetErrorAction());
  }, []);
  useEffect(() => {
    //  console.log("theme",themeState);

    setTheme(themeState);

  }, [themeState])


  useEffect(() => {
    if (error && error.error) {
      let err = error.error;
      if (err && (typeof err) == "string") {
        setMessages(null);
        setMessage({ error_msg: err, status: "danger" });
        setIsFormik(false)
      }
    } else setMessages(null);
  }, [error]);

  useEffect(() => {
    setIsFormik(true)
  }, [formik.errors]);


  useEffect(() => {
    console.log("user data", userData)
  }, [userData])

  return (
    <>

      {/* <CLoader show={loader} /> */}

      <div className="page page-center">
        <div className="container container-normal py-4">
          <div className="row align-items-center g-4">
            <div className="col-lg">
              <div className="container-tight">
                <div className="text-center mb-4">
                  <a href="." className="navbar-brand navbar-brand-autodark"><img src={logo} height={86} alt /></a>
                </div>
                <div className="card card-md">
                  <div className="card-body">

                    <form
                      className="card card-md"
                      onSubmit={formik.handleSubmit}
                      autoComplete="off"
                    >
                      <div className="card-body">
                        <h2 className="card-title text-center mb-4">
                          Login to your account
                        </h2>
                        <div className="row mb-3">
                          {message &&
                            <Alert title={message.error_msg} type={message.status} />}
                          <div className="col-md-12 col-xl-12">
                            <label className="form-label">Email</label>

                            <CInput
                              id="email"
                              name="email"
                              value={formik.values.email}
                              onChange={formik.handleChange}
                              onBlur={formik.handleBlur}
                              error={isFormik ? { type: "formik", error: formik && formik } : { type: "server", error: messages }}
                              type="email"
                            />

                          </div>
                        </div>
                        <div className="row mb-3">
                          <div className="col-md-12 col-xl-12">
                            <label className="form-label">Password

                            </label>
                            <div className="input-group">
                              <CInput
                                id="password"
                                name="password"
                                value={formik.values.password}
                                onChange={formik.handleChange}
                                onBlur={formik.handleBlur}
                                error={isFormik ? { type: "formik", error: formik && formik } : { type: "server", error: messages }}
                                type="password"
                              />
                            </div>
                          </div>
                        </div>
                        <div className="row mb-3">
                          <span className="form-label-description">
                            <a href="/auth/forgot-password" > Forgot Password</a>
                          </span>
                        </div>
                        <div className="form-footer">
                          <button type="submit" className={`btn btn-primary w-100 ${disabled ? "disabled" : ""}`}>
                            Sign in
                          </button>
                        </div>
                      </div>
                    </form>
                  </div>
                </div>
              </div>
            </div>

            <div className="col-lg d-none d-lg-block">
              <div className="col-lg d-none d-lg-block">
                <img src={screenshotImage} className="d-block mx-auto" alt="Screenshot" />
              </div>

            </div>

          </div>
          <div className="text-center text-muted mt-3">
            Don't have account yet?  <Link to="/auth/signup"><strong>Sign up</strong></Link>
          </div>

        </div>
      </div>
    </>
  );
}
export default Signin;
